# Social engineering password generator

THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. YOU MAY USE THIS SOFTWARE AT YOUR OWN RISK. THE USE IS COMPLETE RESPONSIBILITY OF THE END-USER. THE DEVELOPERS ASSUME NO LIABILITY AND ARE NOT RESPONSIBLE FOR ANY MISUSE OR DAMAGE CAUSED BY THIS PROGRAM.

Date: 02/23/2019

Original passgen author: Mohamed

Some changed by: UnderMind0x41

Description: A social engineering password generator

This script required python version >= 3.0

## How To Use
```bash
$ git clone https://github.com/TheUnderMind0x41/PassGen.git
$ cd PassGen/
$ python3 ./passgen.py
```
## In Result
You will get file named by victim firstname.

## Screenshots
<a href="https://ibb.co/h86Zjw3"><img src="https://i.ibb.co/bd02ZDc/1.png" alt="1" border="0"></a>
<a href="https://ibb.co/FYN007F"><img src="https://i.ibb.co/2MmssKT/2.png" alt="2" border="0"></a>
<a href="https://ibb.co/JcKcpYN"><img src="https://i.ibb.co/qDdDgHz/3.png" alt="3" border="0"></a>
<a href="https://ibb.co/QvmnmGL"><img src="https://i.ibb.co/yFs5sJt/4.png" alt="4" border="0"></a>
